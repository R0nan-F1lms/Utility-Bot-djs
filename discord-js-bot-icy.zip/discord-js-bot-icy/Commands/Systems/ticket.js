const { MessageEmbed, CommandInteraction, MessageActionRow, MessageButton } = require("discord.js");

const { T_CH } = require("../../config.json");

module.exports = {
    name: "ticket",
    description: "Setup tickets for this server",
    permission: "ADMINISTRATOR",
    async execute(interaction) {
        const { guild } = interaction;

        const T_E = new MessageEmbed()
        .setTitle("💌 Tickets 💌")
        .setDescription("Have a question or want to report someone? Creating a ticket is easy, just click on the button below!\n\n Made by [Ronan Films](https://ronanfilms.com/portfolio)")
        .setColor("RANDOM");

        const Buttons = new MessageActionRow();
        Buttons.addComponents(
            new MessageButton()
            .setCustomId("open")
            .setLabel("📨")
            .setStyle("SECONDARY")
        );

        const channel = await guild.channels.cache.get(`${T_CH}`);
        const message =  channel.send({ embeds: [T_E], components: [Buttons]})

        const success = new MessageEmbed()
        .setColor("GREEN")
        .setDescription(`Successfully made the ticket`)

        
        await interaction.reply({ 
        embeds: [success],
    });
    }
}