const { CommandInteraction, MessageEmbed, Client } = require("discord.js");

module.exports = {
    name: "ban",
    description: "ban a user",
    permission: "ADMINISTRATOR",
    options: [
        {
            name: "target",
            description: "Provide a user to ban.", // Change able
            type: "USER",
            required: true,
        },
        {
            name: "reason",
            description: "Provide a reason to ban this user", //Change able.
            type: "STRING",
        },
    ],
   /**
     * @param {CommandInteraction} interaction
     */
    async execute(interaction) {
        const { options, guild } = interaction;
        const reason        = options.getString("reason") || "No reason provided";
        const target      = options.getMember("target");


        const Embed = new MessageEmbed()
        .setTitle("⚒️ Ban ⚒️")
        .setDescription(`Banned ${target} reason:\`${reason}\``)
        let message = interaction.reply({embeds: [Embed]})

        const DM = new MessageEmbed()
        .setTitle("⚒️ Ban ⚒️")
        .setDescription(`You have been Banned from the guild (PUT YOUR SERVER NAME HERE), reason:\`${reason}\``)

        target.send({embeds: [DM]}).catch((err)=>{console.log("⛔ Private message blocked by the user")});

        const log = new MessageEmbed()
        .setTitle("Logs | ⚒️ Ban ⚒️")
        .addFields(
            { name: "🔒 Action", value: "Ban" },
            { name: "📘 Author", value: `${interaction.member}` },
            { name: "👾 Member", value: `${target}` },
            { name: "📚 Reason", value: `${reason}` },
        )
        .setColor("RED")

        await guild.channels.cache.get("887910913749958686").send({ embeds: [log] });

        target.ban();
    }
}