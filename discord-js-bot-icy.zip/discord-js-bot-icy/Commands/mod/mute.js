const { CommandInteraction, MessageEmbed } = require("discord.js");

module.exports = {
    name: "toggle-mute",
    description: "Toggle mute for users",
    permission: "MANAGE_ROLES",
    options: [
        {
            name: "target",
            description: "Provide a user to manage.",
            type: "USER",
            required: true,
        },
        {
            name: "reason",
            description: "Provide a reason to toggle mute/on/off this person",
            type: "STRING",
        },
    ],
    /**
     * @param {CommandInteraction} interaction
     */
    async execute(interaction) {
        const { options, guild } = interaction;
        const role           = "917639506872655912";
        const reason        = options.getString("reason") || "No reason provided";
        const target      = options.getMember("target");
        const embed       = new MessageEmbed()
                            .setColor("YELLOW")
                            .setTitle("⚠️ Toggle Mute ⚠️");

        console.log(interaction.member.roles.highest.position);
        console.log(`${reason}`);
        if (!role.editable || interaction.member.roles.highest.position < role.position ) {
            embed.setDescription(`I cannot mute ${target} the muted role may be higher then my role. <@&${role}>`)
            return interaction.reply({ embeds: [embed], ephemeral: true })
        }
        
        embed.setDescription(target.roles.cache.has(role.id) ? `Muted ${target}. ${reason}` : `Added the ${role} role to ${target}.`);
        target.roles.cache.has(role.id) ? target.roles.remove(role) : target.roles.add(role);
        const message = await interaction.reply({embeds: [embed], fetchReply: true});
        setTimeout(() => message.delete().catch(() => {}), 5000);

        const log = new MessageEmbed()
        .setTitle("Logs | ⚠️ Mute ⚠️")
        .addFields(
            { name: "🔒 Action", value: "Mute" },
            { name: "📘 Author", value: `${interaction.member}` },
            { name: "👾 Member", value: `${target}` },
            { name: "📚 Reason", value: `${reason}` },
        )
        .setColor("YELLOW")

        await guild.channels.cache.get("887910913749958686").send({ embeds: [log] });
    }
}
