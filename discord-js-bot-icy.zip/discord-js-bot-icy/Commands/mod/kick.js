const { CommandInteraction, MessageEmbed, Client } = require("discord.js");

module.exports = {
    name: "kick",
    description: "kick a user",
    permission: "ADMINISTRATOR",
    options: [
        {
            name: "target",
            description: "Provide a user to kick.", // Change able
            type: "USER",
            required: true,
        },
        {
            name: "reason",
            description: "Provide a reason to kick this user", //Change able.
            type: "STRING",
        },
    ],
   /**
     * @param {CommandInteraction} interaction
     */
    async execute(interaction) {
        const { options, guild } = interaction;
        const reason        = options.getString("reason") || "No reason provided";
        const target      = options.getMember("target");


        const Embed = new MessageEmbed()
        .setTitle("⚠️ Kick ⚠️")
        .setDescription(`Kicked ${target} reason:\`${reason}\``)
        let message = interaction.reply({embeds: [Embed]})

        const DM = new MessageEmbed()
        .setTitle("⚠️ Kicked ⚠️")
        .setDescription(`You have been KICKED from the guild (PUT YOUR SERVER NAME HERE), reason:\`${reason}\``)

        target.send({embeds: [DM]}) .catch(()=>{console.log("⛔ Private message blocked by the user")});

        const log = new MessageEmbed()
        .setTitle("Logs | ⚠️ Kick ⚠️")
        .addFields(
            { name: "🔒 Action", value: "Kick" },
            { name: "📘 Author", value: `${interaction.member}` },
            { name: "👾 Member", value: `${target}` },
            { name: "📚 Reason", value: `${reason}` },
        )
        .setColor("ORANGE")

        await guild.channels.cache.get("887910913749958686").send({ embeds: [log] });

        target.kick();
    }
}