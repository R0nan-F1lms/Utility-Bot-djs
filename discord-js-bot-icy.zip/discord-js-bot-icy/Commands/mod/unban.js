const { CommandInteraction, MessageEmbed, Client } = require("discord.js");

module.exports = {
    name: "unban",
    description: "unban a user",
    permission: "ADMINISTRATOR",
    options: [
        {
            name: "target",
            description: "Provide a user to unban.", // Change able
            type: "USER",
            required: true,
        },
    ],
   /**
     * @param {CommandInteraction} interaction
     */
    async execute(interaction) {
        const { options, guild } = interaction;
        const target      = options.getMember("target");
        console.log(target)
        
        const Embed = new MessageEmbed()
        .setTitle("⚒️ UnBan ⚒️")
        .setDescription(`unBanned ${target}`)
        let message = interaction.reply({embeds: [Embed]})

        const log = new MessageEmbed()
        .setTitle("Logs | ⚒️ UnBan ⚒️")
        .addFields(
            { name: "🔒 Action", value: "Unban" },
            { name: "📘 Author", value: `${interaction.member}` },
            { name: "👾 Member", value: `${target}` },
        )
        .setColor("GREEN")
        


        await guild.channels.cache.get("887910913749958686").send({ embeds: [log] });
        
target.unban()
        
    }
}