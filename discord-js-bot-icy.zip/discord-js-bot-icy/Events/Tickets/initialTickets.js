const { ButtonInteraction, MessageButton, MessageEmbed, MessageActionRow  } = require("discord.js");

const DB = require("../../Schemas/Ticket");
const { P_ID, E_ID, S_ID } = require("../../config.json")

module.exports = {
    name: "interactionCreate",
    /**
     * 
     * @param {ButtonInteraction} interaction 
     */
    async execute(interaction)  {
        if(!interaction.isButton()) return;
        const { guild, member, customId } = interaction;
        if(!["open"].includes(customId)) return;


        const ID = Math.floor(Math.random() * 90000) + 10000;



        await guild.channels.create(`${member.user.username}` + "-" + `${ID}`, {
            type: "GUILD_TEXT",
            parent: P_ID, 
            topic: `Ticket - ${member.user.username}#${member.user.discriminator}\nTicket ID: ${ID}`,
            permissionOverwrites: [
            {
              id: E_ID,
                deny: [
                  "SEND_MESSAGES",
                  "VIEW_CHANNEL",
                  "READ_MESSAGE_HISTORY",
                ],
              },
              {
                id: S_ID,
                  allow: [
                    "SEND_MESSAGES",
                    "VIEW_CHANNEL",
                    "READ_MESSAGE_HISTORY",
                  ],
                },
                {
                    id: member.id,
                      allow: [
                        "SEND_MESSAGES",
                        "VIEW_CHANNEL",
                        "READ_MESSAGE_HISTORY",
                      ],
                    
                }     
            ]
            }).then(async(channel) => {
                await DB.create({
                    GuildID: guild.id,
                    MemberID: member.id,
                    TicketID: ID,
                    ChannelID:channel.id,
                    Closed: false,
                    Locked: false,
                    type: customId
                });

                const O_T = new MessageEmbed()
                .setTitle(`${member.user.username}#${member.user.discriminator}'s ticket`)
                .setDescription(`Please wait for a staff to come and assist you, remember that our staff are volunteers and that they have a life out side of discord.`)
                
                const Buttons = new MessageActionRow()
                Buttons.addComponents(
                    new MessageButton()
                    .setCustomId("close")
                    .setLabel("🔒")
                    .setStyle("SECONDARY")
                );
    
                channel.send({content: `${member} here is your ticket`, embeds: [O_T], components: [Buttons]});
    
                interaction.reply({content: `${member} your ticket has been created in ${channel}`, ephemeral: true})

            });
    },
}
