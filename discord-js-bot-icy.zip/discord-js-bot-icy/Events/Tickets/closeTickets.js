const { ButtonInteraction, MessageEmbed } = require("discord.js");
const { createTranscript } = require("discord-html-transcripts");
const { L_CH } = require("../../config.json");
const DB = require("../../Schemas/Ticket");
const { lineBreak } = require("acorn");


module.exports = {
    name: "interactionCreate",
    /**
     * @param {ButtonInteraction} interaction 
     */
    async execute(interaction) {
        if (!interaction.isButton()) return;

        const { guild, customId, channel, member } = interaction;
        if(!member.permissions.has("ADMINISTRATOR")) return interaction.reply({content: "You cannot use these buttons", ephemeral: true})
        if(!["close"].includes(customId)) return;

    const Embed = new MessageEmbed().setColor("BLURPLE");

    DB.findOne({ channelID: channel.id }, async (err, docs) => {
        if (err) throw err;
        if(!docs)
        return interaction.reply({
            content: "No Data found relating to this ticket, please delete it manually",
            ephemeral: true
        });
        switch(customId) {
            case "close":
               if (docs.Closed == true) 
               return interaction.reply({
                   content: "This ticket is already closed, please wait for it be deleted",
                   ephemeral: true
               });
               const attachment = await createTranscript(channel, {
                limit: -1,
                returnBuffer: false,
                fileName: `${docs.Type} - ${docs.TicketID}.html`
               });

               await DB.updateOne({ ChannelID: channel.id }, { Closed: true });

               const MEMBER = guild.members.cache.get(docs.MemberID)
               const Message = await guild.channels.cache.get(L_CH).send({
                   embeds: [
                       Embed
                       .setAuthor(MEMBER.user.tag, 
                        MEMBER.user.displayAvatarURL({ dynamic: true })
                        )
                        .setTitle(`Transcript Type: ${docs.Type}\nID: ${docs.TicketID}`)
                   ],
                   files: [attachment]
               });

               interaction.reply({embeds: [Embed.setDescription(
                   `The transcript is now saved [TRANSCRIPT](${Message.url})`
               )
            ]
        });

        setTimeout(() => {
            channel.delete();
        }, 10 * 1000);
        }
    });
    }
} 