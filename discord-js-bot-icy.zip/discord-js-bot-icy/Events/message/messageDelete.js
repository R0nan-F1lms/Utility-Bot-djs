const { MessageEmbed, Message } = require("discord.js");

module.exports = {
    name: "messageDelete",
    /**
     * @param {Message} message
     */
    execute(message) {
        if(message.author.bot) return;

console.log(`MESSAGE DELETED`);

        const Log = new MessageEmbed()
        .setColor("#000000")
        .setDescription(`📕 A [message](${message.url}) by ${message.author.tag} was **Deleted**.\n**Deleted Message**:\n${message.content ? message.content : "None"}`.slice(0, 4096))

        if(message.attachments.size >= 1){
            Log.addField(`Attachments:`, `${message.attachments.map(a => a.url)}`, true);
        }
        const channel = message.guild.channels.cache.get("Log channel ID");
        channel.send({ embeds: [Log] });
    }
}