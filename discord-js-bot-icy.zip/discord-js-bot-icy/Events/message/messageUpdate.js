const { MessageEmbed, Message, Client } = require("discord.js");

module.exports = {
    name: "messageUpdate",
    /**
     * 
     * @param {Message} oldMessage 
     * @param {Message} newMessage 
     */
    execute(oldMessage, newMessage) {
        if(oldMessage.author.bot) return;
        // If a bot ignore.

        if(oldMessage.content === newMessage.content) return;

        const Count = 1950;
        console.log(`MESSAGE Edited`)
        const Original = oldMessage.content.slice(0, Count) + (oldMessage.content.length > 1950 ? " ..." : "");
        const Edited = newMessage.content.slice(0, Count) + (newMessage.content.length > 1950 ? " ..." : "");

        const log = new MessageEmbed()
        .setColor("#000000")
        .setDescription(`📘 A [message](${newMessage.url}) by ${newMessage.author} was **edited** in ${newMessage.channel}.\n **Original**:\n ${Original} \n**Edited**: \n ${Edited}`.slice("0", "4096"))
        

        const channel = oldMessage.guild.channels.cache.get("Log Channel I");
        channel.send({ embeds: [log] })
    }
}